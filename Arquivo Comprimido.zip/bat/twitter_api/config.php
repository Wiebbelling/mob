<?php
/**
 * Your Twitter App Info
 */

// Consumer Key
define('CONSUMER_KEY', 'AhbLzsQx0WnSCSYegeQplGkIb');
define('CONSUMER_SECRET', '79eEkiXhPprOlGoR2Hd8fl8ftu8CdrerfK8hp0dlCFBGMFwS0p');

// User Access Token
define('ACCESS_TOKEN', '3158216636-efFJGyXmK4CrOTEbDCwLemzf8DSN4xWkYDWH45R');
define('ACCESS_SECRET', '05oMcv6LXgHuxgAvijmafVzZmth0JmygSrSR5lJGwWcEH');

// Cache Settings
define('CACHE_ENABLED', false);
define('CACHE_LIFETIME', 3600); // in seconds
define('HASH_SALT', md5(dirname(__FILE__)));